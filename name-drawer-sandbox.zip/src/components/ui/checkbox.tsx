
import React from 'react'

type Props = {
  id?: string
  checked?: boolean
  onCheckedChange?: (checked: boolean) => void
} & React.InputHTMLAttributes<HTMLInputElement>

export function Checkbox({ id, checked, onCheckedChange, ...rest }: Props) {
  return (
    <input
      id={id}
      type="checkbox"
      checked={!!checked}
      onChange={(e) => onCheckedChange && onCheckedChange(e.target.checked)}
      className="h-4 w-4 rounded border-gray-300"
      {...rest}
    />
  )
}
