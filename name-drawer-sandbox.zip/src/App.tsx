
import React, { useEffect, useMemo, useRef, useState } from 'react'
import { Button } from './components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from './components/ui/card'
import { Input } from './components/ui/input'
import { Label } from './components/ui/label'
import { Checkbox } from './components/ui/checkbox'
import { Textarea } from './components/ui/textarea'
import { Download, Upload, Shuffle, Copy, Trash2, Save, Undo2 } from 'lucide-react'
import { motion, AnimatePresence } from 'framer-motion'

function getRandomInt(max: number) {
  if (max <= 0) return 0
  if (typeof crypto !== 'undefined' && 'getRandomValues' in crypto) {
    const array = new Uint32Array(1)
    crypto.getRandomValues(array)
    return array[0] % max
  }
  return Math.floor(Math.random() * max)
}

function sampleWithoutReplacement<T>(arr: T[], k: number): T[] {
  const copy = [...arr]
  const result: T[] = []
  const n = Math.min(k, copy.length)
  for (let i = 0; i < n; i++) {
    const idx = getRandomInt(copy.length)
    result.push(copy[idx])
    copy.splice(idx, 1)
  }
  return result
}

function parseNames(raw: string): string[] {
  return raw
    .split(/\r?\n|,|;/g)
    .map((s) => s.trim())
    .filter((s) => s.length > 0)
}

function uniq<T>(a: T[]): T[] {
  return Array.from(new Set(a))
}

const STORAGE_KEY = 'nameDrawer.names.v1'
const STORAGE_DRAWN_KEY = 'nameDrawer.drawn.v1'

export default function App() {
  const [rawNames, setRawNames] = useState<string>('')
  const [drawn, setDrawn] = useState<string[]>([])
  const [count, setCount] = useState<number>(1)
  const [uniqueDraws, setUniqueDraws] = useState<boolean>(true)
  const [shuffleList, setShuffleList] = useState<boolean>(false)
  const [message, setMessage] = useState<string>('')
  const fileRef = useRef<HTMLInputElement | null>(null)

  const names = useMemo(() => uniq(parseNames(rawNames)), [rawNames])
  const remaining = useMemo(() => names.filter((n) => !drawn.includes(n)), [names, drawn])

  useEffect(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY)
      if (saved) setRawNames(saved)
      const savedDrawn = localStorage.getItem(STORAGE_DRAWN_KEY)
      if (savedDrawn) setDrawn(JSON.parse(savedDrawn))
    } catch {}
  }, [])

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, rawNames)
      localStorage.setItem(STORAGE_DRAWN_KEY, JSON.stringify(drawn))
    } catch {}
  }, [rawNames, drawn])

  function handleDraw() {
    setMessage('')
    const pool = uniqueDraws ? remaining : names
    if (pool.length === 0) {
      setMessage('No names available to draw from.')
      return
    }
    const k = Math.max(1, Math.min(count, pool.length))
    const picks = uniqueDraws
      ? sampleWithoutReplacement(pool, k)
      : Array.from({ length: k }, () => pool[getRandomInt(pool.length)])

    const finalPicks = shuffleList ? [...picks].sort(() => (Math.random() - 0.5)) : picks
    setDrawn((d) => uniq([...d, ...finalPicks]))
  }

  function handleResetAll() {
    setDrawn([])
  }

  function handleUndoLast() {
    setDrawn((d) => d.slice(0, Math.max(0, d.length - 1)))
  }

  async function copyWinners() {
    const text = drawn.join('\n')
    try {
      await navigator.clipboard.writeText(text)
      setMessage('Copied winners to clipboard.')
    } catch {
      setMessage('Could not copy to clipboard.')
    }
  }

  function downloadCSV() {
    const blob = new Blob(['Name\n' + drawn.map((n) => `"${n.replace(/"/g, '""')}"`).join('\n')], { type: 'text/csv;charset=utf-8;' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = 'winners.csv'
    document.body.appendChild(a)
    a.click()
    a.remove()
    URL.revokeObjectURL(url)
  }

  function handleUploadFile(file: File) {
    const reader = new FileReader()
    reader.onload = (e) => {
      const text = String(e.target?.result || '')
      setRawNames((prev) => {
        const next = uniq([...parseNames(prev), ...parseNames(text)]).join('\n')
        return next
      })
    }
    reader.readAsText(file)
  }

  return (
    <div className="min-h-screen w-full bg-gradient-to-b from-slate-50 to-white">
      <div className="mx-auto max-w-5xl px-4 py-8">
        <header className="mb-6">
          <h1 className="text-3xl font-bold tracking-tight">Name Drawer</h1>
          <p className="text-slate-600">Paste a list of names, choose how many to draw, and pick winners with fair randomness.</p>
        </header>

        <div className="grid grid-cols-1 gap-6 md:grid-cols-2">
          <Card className="shadow-sm">
            <CardHeader>
              <CardTitle className="text-xl">Name List</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="names">Enter names (one per line, or comma-separated)</Label>
                <Textarea
                  id="names"
                  value={rawNames}
                  onChange={(e) => setRawNames(e.target.value)}
                  placeholder={`Alice\nBob\nCharlie`}
                  className="h-56 resize-y"
                />
                <div className="flex items-center justify-between text-sm text-slate-500">
                  <span>Total unique: <strong>{names.length}</strong></span>
                  <span>Remaining: <strong>{remaining.length}</strong></span>
                </div>
              </div>

              <div className="flex flex-wrap gap-2">
                <Button variant="secondary" onClick={() => setRawNames(names.join('\n'))}>
                  <Save className="mr-2 h-4 w-4" /> Deduplicate
                </Button>
                <Button variant="secondary" onClick={() => setRawNames('')}>
                  <Trash2 className="mr-2 h-4 w-4" /> Clear List
                </Button>
                <input
                  ref={fileRef}
                  type="file"
                  accept=".txt,.csv"
                  className="hidden"
                  onChange={(e) => {
                    const f = e.target.files?.[0]
                    if (f) handleUploadFile(f)
                    if (fileRef.current) fileRef.current.value = ''
                  }}
                />
                <Button variant="outline" onClick={() => fileRef.current?.click()}>
                  <Upload className="mr-2 h-4 w-4" /> Import .csv/.txt
                </Button>
              </div>
            </CardContent>
          </Card>

          <Card className="shadow-sm">
            <CardHeader>
              <CardTitle className="text-xl">Draw Controls</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                <div className="space-y-2">
                  <Label htmlFor="count">Number to draw</Label>
                  <Input
                    id="count"
                    type="number"
                    min={1}
                    value={count}
                    onChange={(e) => setCount(parseInt(e.target.value || '1', 10))}
                  />
                </div>
                <div className="space-y-2">
                  <Label>Options</Label>
                  <div className="flex items-center gap-2">
                    <Checkbox id="unique" checked={uniqueDraws} onCheckedChange={(v) => setUniqueDraws(Boolean(v))} />
                    <Label htmlFor="unique" className="text-sm">No repeats (draw without replacement)</Label>
                  </div>
                  <div className="mt-2 flex items-center gap-2">
                    <Checkbox id="shuffle" checked={shuffleList} onCheckedChange={(v) => setShuffleList(Boolean(v))} />
                    <Label htmlFor="shuffle" className="text-sm">Shuffle order of picks</Label>
                  </div>
                </div>
              </div>

              <div className="flex flex-wrap gap-2">
                <Button onClick={handleDraw}>
                  <Shuffle className="mr-2 h-4 w-4" /> Draw
                </Button>
                <Button variant="secondary" onClick={handleUndoLast}>
                  <Undo2 className="mr-2 h-4 w-4" /> Undo last
                </Button>
                <Button variant="outline" onClick={handleResetAll}>
                  <Trash2 className="mr-2 h-4 w-4" /> Reset winners
                </Button>
              </div>

              {message && (
                <div className="rounded-md bg-amber-50 p-3 text-sm text-amber-800 border border-amber-200">{message}</div>
              )}
            </CardContent>
          </Card>
        </div>

        <Card className="mt-6 shadow-sm">
          <CardHeader>
            <CardTitle className="text-xl">Winners</CardTitle>
          </CardHeader>
          <CardContent>
            {drawn.length === 0 ? (
              <p className="text-slate-500">No winners drawn yet.</p>
            ) : (
              <div>
                <div className="mb-4 flex flex-wrap gap-2">
                  <Button variant="secondary" onClick={copyWinners}>
                    <Copy className="mr-2 h-4 w-4" /> Copy
                  </Button>
                  <Button variant="outline" onClick={downloadCSV}>
                    <Download className="mr-2 h-4 w-4" /> Download CSV
                  </Button>
                </div>

                <ul className="grid grid-cols-1 gap-2 sm:grid-cols-2 lg:grid-cols-3">
                  <AnimatePresence>
                    {drawn.map((name) => (
                      <motion.li
                        key={name}
                        initial={{ opacity: 0, y: 8 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, y: -8 }}
                        className="rounded-2xl border border-slate-200 bg-white p-3 shadow-sm"
                      >
                        <div className="flex items-center justify-between">
                          <span className="font-medium">{name}</span>
                          <Button
                            size="sm"
                            variant="ghost"
                            onClick={() => setDrawn((d) => d.filter((x) => x !== name))}
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </motion.li>
                    ))}
                  </AnimatePresence>
                </ul>
              </div>
            )}
          </CardContent>
        </Card>

        <footer className="mt-10 text-center text-xs text-slate-400">
          <p>Names and results save locally in your browser. No data leaves your device.</p>
        </footer>
      </div>
    </div>
  )
}
